
<?php $__env->startSection('title', 'Acceso App'); ?>

<?php $__env->startSection('content'); ?>
   <div class="flex h-screen items-center justify-center bg-gray-200">
      <div class="bg-white p-8 rounded shadow w-1/2">
         <h1 class="flex items-center font-sans font-bold break-normal text-indigo-500 px-2 py-4 text-xl md:text-2xl mb-4">Ingresar dispositivo</h1>
         <form action="<?php echo e(route('dispositivos.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo $__env->make('dispositivos._form',['btnText' => 'Guardar datos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </form>
      </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\acceso-app\resources\views/dispositivos/create.blade.php ENDPATH**/ ?>