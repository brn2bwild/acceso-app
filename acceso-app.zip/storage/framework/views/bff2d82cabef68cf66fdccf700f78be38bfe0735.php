<?php echo csrf_field(); ?>
<?php if(isset($atleta->Foto)): ?>
<div class="flex flex-wrap justify-center">
      <div class="w-6/12 sm:w-4/12 px-4">
        <img src="<?php echo e(asset('storage').'/'.$atleta->Foto); ?>" alt="" class="shadow rounded-full max-w-full h-auto align-middle border-none" />
      </div>
    </div>
      
<?php endif; ?>
<div>
      <label for="Nombre" class="block py-1">Nombre</label>
      <input type="text" name="Nombre" id="nombre" value="<?php echo e(old('Nombre',$atleta->Nombre)); ?>" class="w-full border border-gray-400 rounded focus:border-indigo-400">
</div>

<div>
      <label for="apellidoPaterno" class="block py-1">Apellido Materno</label>
      <input type="text" name="apellidoPaterno" id="apellidopaterno" value="<?php echo e(old('apellidoPaterno',$atleta->apellidoPaterno)); ?>" class="w-full border border-gray-400 rounded focus:border-indigo-400">
</div>

<div>
      <label for="apellidoMaterno" class="block py-1">Apellido Paterno</label>
      <input type="text" name="apellidoMaterno" id="apellidomaterno" value="<?php echo e(old('apellidoMaterno',$atleta->apellidoMaterno)); ?>" class="w-full border border-gray-400 rounded focus:border-indigo-400">
</div>

<div>
      <label for="Correo" class="block py-1">Correo</label>
      <input type="text" name="Correo" id="correo" value="<?php echo e(old('Correo',$atleta->Correo)); ?>" class="w-full border border-gray-400 rounded focus:border-indigo-400">
</div>

<div class="flex w-full">
      <div class="w-1/2">
            <label for="RFID" class="block py-1">RFID</label>
            <input type="text" name="RFID" id="correo" value="<?php echo e(old('Correo',$atleta->RFID)); ?>" class="w-full border border-gray-400 rounded focus:border-indigo-400 mr-4" maxlength="10">
      </div>

      <div class="inline-flex py-8 px-4 items-center justify-between">
            <label for="Autorizado">Autorización</label>
            <input type="checkbox" name="Autorizado" id="Autorizado" class="border border-gray-400 rounded focus:border-indigo-400 ml-4" maxlength="10"
            <?php if($atleta->Autorizado == 'true'): ?>
                checked                
            <?php endif; ?>>
      </div>
</div>

<div>
      <label for="Foto" class="block py-1">Foto</label>
      <input type="file" name="Foto" id="foto" value="<?php echo e(old('Foto',$atleta->Foto)); ?>" class="w-full border border-gray-400 rounded focus:border-indigo-400">
</div>

<div class="flex justify-around mt-8">
      <input type="submit" value="<?php echo e($btnText); ?>" class="px-5 py-2 bg-indigo-400 rounded">
      <a href="<?php echo e(route('atletas.index')); ?>" class="px-5 py-2 rounded border border-indigo-400">Regresar</a>
</div>
<?php /**PATH C:\xampp\htdocs\acceso-app\resources\views/atletas/_form.blade.php ENDPATH**/ ?>