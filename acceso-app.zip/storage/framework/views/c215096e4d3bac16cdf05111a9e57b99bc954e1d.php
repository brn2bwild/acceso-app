

<?php $__env->startSection('title', 'Registros'); ?>

<?php $__env->startSection('content'); ?>
   <div class="container w-full md:w-4/5 xl:w-4/5 mx-auto px-2">
      <h1 class="flex items-center font-sans font-bold break-normal text-indigo-500 px-2 py-8 text-xl md:text-2xl">Registros</h1>
      <div id="recipients" class="p-8 mt-6 lg:mt-0 rounded shadow bg-white">
         <table id="registros" class="stripe hover" style="width:100%; padding-top:1em; padding-bottom:1em">
            <thead>
               <tr class="bg-indigo-400 bg-opacity-100 text-white">
                  <th data-priority="1" class="w-1/5">Nombre</th>
                  <th data-priority="2" class="w-1/5">Apellido Paterno</th>
                  <th data-priority="3" class="w-1/5">Apellido Materno</th>
                  <th data-priority="4" class="w-1/5">Hora Acceso</th>
                  <th data-priority="5" class="w-1/5">Lugar</th>
               </tr>
            </thead>
            <tbody>
               <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                     <td><?php echo e($registro->Nombre); ?></td>
                     <td><?php echo e($registro->apellidoPaterno); ?></td>
                     <td><?php echo e($registro->apellidoMaterno); ?></td>
                     <td><?php echo e($registro->horaAcceso); ?></td>
                     <td><?php echo e($registro->lugarAcceso); ?></td>
                  </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                   
               <?php endif; ?>
            </tbody>
         </table>
      </div>
   </div>
<?php $__env->stopSection(); ?>

<!-- jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>		
<!--Datatables -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script>
   $(document).ready(function(){
      $('#registros').DataTable({
         "lengthChange": false,
         responsive: true,
      }).columns.adjust()
      .responsive.recalc();
   });
</script>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\acceso-app\resources\views/registros/index.blade.php ENDPATH**/ ?>