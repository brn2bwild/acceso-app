<!DOCTYPE html>
<html lang="en" class="antialiased">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta http-equiv="X-UA-Compatible" content="ie=edge">
   <link rel="stylesheet" href="https://unpkg.com/tailwindcss/dist/tailwind.min.css">
   <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
   <link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js">
   <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
   <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
   <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
   <title><?php echo $__env->yieldContent('title'); ?></title>
   
</head>
<body class="bg-gray-200 text-gray-900 tracking-wider leading-normal">
   <header>
      <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   </header>
   
   <?php echo $__env->yieldContent('content'); ?>
   
</body>
<!-- jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-3.4.1.min.js"></script>		
<!--Datatables -->
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
</html><?php /**PATH C:\xampp\htdocs\acceso-app\resources\views/layout.blade.php ENDPATH**/ ?>